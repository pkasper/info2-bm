"""
This is a basic example of creating a package


"""

#Reference for from inheritance_example import *
__all__ = ['student_manager']

#Include the submodules
from .student_manager import *

