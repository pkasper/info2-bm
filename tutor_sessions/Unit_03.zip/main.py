import student_manager_py as student_manager

s = student_manager.StudentManger("csv")