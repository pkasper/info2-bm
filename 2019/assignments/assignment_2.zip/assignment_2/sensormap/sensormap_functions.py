######################################################################
# Author: Malte Hupe
# MatNr: 1647577
# Description: Ass 2
# Comments: ---
######################################################################
import pandas, numpy
from .coordinates import Coordinates
from .city import City

def read_cities(path, countries=[]):
    countries =  [c.lower() for c in countries]
    print(countries[0])
    colorcode = ['red', 'blue', 'green', 'purple', 'orange', 'darkred',\
             'lightred', 'beige', 'darkblue', 'darkgreen', 'cadetblue',\
             'darkpurple', 'white', 'pink', 'lightblue', 'lightgreen',\
             'gray', 'black', 'lightgray']
    citylist = []    
    data = pandas.read_csv(path)

    
    if len(countries) == 0:
        
        for index, row in data.iterrows():
            citylist.append(City(row['city'], Coordinates(row['lat'],row['lng']), row['population'], row['country'], numpy.random.choice(colorcode)))

                  
    else:
       
        for index, row in data.iterrows():
            if row['country'].lower() in countries:           
                citylist.append(City(row['city'], Coordinates(row['lat'],row['lng']), row['population'], row['country'], numpy.random.choice(colorcode)))
        
    return citylist
            


def find_nearest_city(cities, coords):
    for city in cities:
        Coordinates.distance(coords, city.coords)
        

def parse_sensors(data_path, cities):
    pass

def create_map(plot_list, filename, plot_sensor_values=False, smooth=False, zoom=10):
    pass
