"""This package is a basic example of how to use modules

Here comes the long text
"""
def factorial(n): 
    result = 1
    for i in range(2, n+1): result *= i
    return result


print("This line will be executed when imported")


if __name__ == "__main__":
    print("This code will not be executed when imported.")
    print("Only when called as an Application!")