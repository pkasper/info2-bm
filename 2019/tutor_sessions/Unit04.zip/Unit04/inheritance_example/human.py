class Human:
    """This is a basic parent class
    
    Here comes the long description
    """
    pass