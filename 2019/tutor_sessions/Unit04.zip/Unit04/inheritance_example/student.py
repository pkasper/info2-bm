from .human import *

class Student(Human):
    """This is a basic student class
    
    Here comes the long description
    """
    pass