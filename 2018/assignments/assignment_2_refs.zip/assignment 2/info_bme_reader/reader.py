from abc import ABCMeta, abstractmethod
import os
import pickle

import numpy as np
import matplotlib.pyplot as plt


class Reader(metaclass=ABCMeta):
    def __init__(self, data_dir):
        """Constructor. 
        Arguments:
        data_dir -- the directory where the data is stored.
        """
        if not os.path.exists(data_dir):
            raise FileNotFoundError("Data path does not exist")
        self._data_dir = data_dir
        self._X = None
        self._y = None
        self._num_rows = None
        self._num_cols = None

      
    @property
    def X(self):
        """Property for the array of feature matrices X.
        We manually block the setter.
        """
        if self._X is None:
            raise ValueError("The feature matrices are not set yet")
        return self._X

    @X.setter
    def X(self, _):
        raise NameError("You are not allowed to manually set the feature matrices")
        
    @property
    def y(self):
        """Property for the array of labels y.
        We manually block the setter.
        """
        if self._y is None:
            raise ValueError("The labels are not set yet")
        return self._y

    @y.setter
    def y(self, _):
        raise NameError("You are not allowed to manually set the labels")
        
    @property
    def num_rows(self):
        """Property for number of rows per sample.
        Setting is allowed here... We might need that later
        """
        return self._num_rows

    @num_rows.setter
    def num_rows(self, num_rows):
        """Setter for num_rows
        
        Arguments:
        num_rows -- The number of rows. (int)
        """
        assert isinstance(num_rows, int)
    
    
    @property
    def num_cols(self):
        """Property for number of rows per sample.
        Setting is allowed here... We might need that later
        """
        return self._num_cols

    @num_cols.setter
    def num_cols(self, num_cols):
        """Setter for num_cols
        
        Arguments:
        num_cols -- The number of cols. (int)
        """
        assert isinstance(num_cols, int)
    
    @abstractmethod
    def read_data(self):
        """Interface method to read the data. Has to be overwritten by the inheriting classes.
        """
        raise NotImplementedError

    def plot_sample(self, sample_index, output_path):
        """Plots a number.
        Arguments:
        index -- the index of the sample to be visualised
        output_path -- the complete path to the file where the image is stored (including extension).
        """
        sample_features = self.X[sample_index].reshape((self._num_rows, self._num_cols))
        figure, axis = plt.subplots(figsize=(7, 7))
        axis.imshow(sample_features, interpolation='nearest', cmap='Greys')
        axis.set_title("Sample #{i} , Label: {l}".format(i=sample_index, l=self._y[sample_index]))
        axis.set_xticks([])
        axis.set_yticks([])

        figure.savefig(output_path)
        
    def dump(self, output_name):
        """Dumps the loaded data in the pickle format
        Argument:
        output_name -- The complete path to the file where the dump should be stored. (Ignores the data_dir)
        """
        dump_data = {
            "X": self._X,
            "y": self._y,
            "num_rows": self._num_rows,
            "num_cols": self._num_cols,
        }
        
        try:
            with open(output_name, "wb") as dump_file:
                pickle.dump(dump_data, dump_file)
        except OSError:
            print("Error writing pickle file!")