import os
import gzip
import struct

import numpy as np

from .reader import Reader


class MnistReader(Reader):
    def __init__(self, data_dir):
        """Constructor. 
        Arguments:
        data_dir -- the directory where the binary data is stored.
        """
        super().__init__(data_dir)

    def _fetch_magic_number(self, mnist_file):
        """[private] Function to extract the magic number from the MNIST files.
        Arguments: 
        mnist_file -- path to the file
        """
        with gzip.open(mnist_file) as data_file:
            magic_number = struct.unpack(">i", data_file.read(4))[0]
            return magic_number

    def _fetch_num_items(self, mnist_file):
        """[private] Function to extract the number of items from the MNIST files.
        Arguments: 
        mnist_file -- path to the file
        """
        offset = 4
        with gzip.open(mnist_file) as data_file:
            num_items = struct.unpack_from(">i", data_file.read(4 + offset), offset)[0]
            return num_items

    def _extract_features(self, mnist_file):
        """[private] Function to extract the features from the MNIST files.
        Arguments: 
        mnist_file -- path to the file
        """
        with gzip.open(mnist_file) as data_file:
            data_file.seek(8)
            self._num_rows = num_rows = struct.unpack(">i", data_file.read(4))[0]
            self._num_cols = num_cols = struct.unpack(">i", data_file.read(4))[0]
            values_per_image = num_rows * num_cols
            features = list(struct.iter_unpack(values_per_image * "B", data_file.read()))
        return np.array(features)

    def _extract_labels(self, label_file):
        """[private] Function to extract the labels from the MNIST files.
        Arguments: 
        mnist_file -- path to the file
        """
        with gzip.open(label_file) as data_file:
            data_file.seek(8)
            labels = [x[0] for x in struct.iter_unpack("B", data_file.read())]
        return np.array(labels)

    def read_data(self, features, labels):
        """[private] Overrides the read_data function from the parent class.
        Reads from the original MNIST files and extracts the features, labels and dimensions.
        
        Arguments: 
        features -- Tuple (file_name, magic number) for the feature file.
        labels -- Tuple (file_name, magic number) for the labels file.
        """
        paths = os.path.join(self._data_dir, features[0]), os.path.join(self._data_dir, labels[0])
        magic_numbers = features[1], labels[1]

        # Make sure the files are there
        for path in paths:
            if not os.path.isfile(path):
                raise FileNotFoundError("File not found: {path}".format(path=path))

        # Verify the magic number
        for path, magic_number in zip(paths, magic_numbers):
            assert isinstance(magic_number, int)
            magic_num_read = self._fetch_magic_number(path)
            if magic_num_read != magic_number:
                raise ValueError("Magic numbers do not match. \nExpected: {e}\nReceived: {r}".format(e=magic_number,
                                                                                                     r=magic_num_read))

        if self._fetch_num_items(paths[0]) != self._fetch_num_items(paths[1]):
            raise ValueError("Number of items for features and labels do not match")

        # Store data to the properties
        self._X = self._extract_features(paths[0])
        self._y = self._extract_labels(paths[1])
