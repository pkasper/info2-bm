import numpy as np
from collections import defaultdict, Counter
from matplotlib import pyplot as plt

from info_bme_reader.reader import Reader


class InfoBme:
    def __init__(self, reader):
        """Constructor. 
        Arguments:
        reader -- the reader instance to work with. Must be of type info_bme_reader.
        """
        assert isinstance(reader, Reader)
        self._reader = reader
        self.read_data = self._reader.read_data

    @property
    def X(self):
        """Property for the array of feature matrices X. 
        Grabs it from the reader and converts it to a numpy array to be sure
        """
        return np.array(self._reader.X)

    @property
    def y(self):
        """Property for the array of label vector y. 
        Grabs it from the reader and converts it to a numpy array to be sure
        """
        return np.array(self._reader.y)

    def calc_balance(self, indices):
        """
        This function calculates the label balance for a given set of indices.
        Returns a dict [class]:[number of samples]

        Arguments:
        indices -- the indices of the target samples
        """
        indices = self._convert_indices(indices)
        y_target = self.y[indices]

        # there are many ways to do this. The Counter class is just really handy as it does exactly what we want
        counts = Counter(y_target)

        # add any labels that are not in the counter so we always return the same structure
        # in the same process turn it into a normal dict
        # these two things were not explicitly asked...
        return {key: counts[key] if key in counts.keys() else 0 for key in set(self.y)}

    def calc_bbox(self, indices, plot=False, plot_name=None):
        """
        This function calculates the bounding box for a set of features.
        If requested, it plots the mean image and marks the bounding box.
        Returns tuple of the corner points (each defined by a x,y -tuple)

        Arguments:
        indices -- the indices of the target samples
        plot -- bool to request a plot
        plot_name -- path to the plot (if requested)
        """
        # we do some optional plotting. nobody asked for it but it never hurts...

        # we wouldnt need to convert the indices because calc means does it to. but rather safe than sorry
        indices = self._convert_indices(indices)
        means = self.calc_means(indices).reshape((28, 28))

        # sum it up over columns and rows and see which are not zero
        vertical_sum_nonzero = means.sum(axis=1).nonzero()[0]
        horizontal_sum_nonzero = means.sum(axis=0).nonzero()[0]

        # the corner points are the first and last nonzero rows
        p_0 = vertical_sum_nonzero[0], horizontal_sum_nonzero[0]
        p_1 = vertical_sum_nonzero[-1], horizontal_sum_nonzero[-1]

        if plot:
            assert plot_name

            figure, axis = plt.subplots(figsize=(7, 7))
            axis.imshow(means, interpolation='nearest', cmap='Greys')

            # the 0.5 offset is so that the line matches translation by imshow
            axis.axhline(vertical_sum_nonzero[0] - 0.5)
            axis.axhline(vertical_sum_nonzero[-1] + 0.5)
            axis.axvline(horizontal_sum_nonzero[0] - 0.5)
            axis.axvline(horizontal_sum_nonzero[-1] + 0.5)
            figure.savefig(plot_name)

        return p_0, p_1

    def calc_cosine_similarity(self, features_a, features_b, plot=False, plot_name=None):
        """
        This function calculates the cosine similarity of two vectors.
        If requested, it plots a corellation plot (scatter)
        Returns the cosine similarity 

        Arguments:
        features_a -- first feature vector
        features_b -- second feature vector
        plot -- bool to request a plot
        plot_name -- path to the plot (if requested)
        """
        assert isinstance(features_a, np.ndarray) and isinstance(features_b, np.ndarray)

        sim_cosine = np.dot(features_a, features_b) / (
                np.sqrt(np.sum(features_a ** 2)) * np.sqrt(np.sum(features_b ** 2)))

        if plot:
            assert plot_name
            figure, axis = plt.subplots()
            axis.scatter(features_a, features_b)
            figure.savefig(plot_name)

        return sim_cosine

    def calc_hist(self, indices, plot=False, plot_name=None):
        """
        This function calculates the histogram of values for a set of samples.
        If requested, it also plots the histogram
        Returns a dict of [color value]:[number of occurrences]

        Arguments:
        indices -- the indices of the target samples
        plot -- bool to request a plot
        plot_name -- path to the plot (if requested)
        """
        indices = self._convert_indices(indices)
        target = self.X[indices].flatten()
        max_value = target.max()
        counts = Counter(target)
        count_dict = {key: counts[key] if key in counts.keys() else 0 for key in np.arange(max_value)}

        if plot:
            assert plot_name
            figure, axis = plt.subplots()
            axis.fill_between(count_dict.keys(), np.zeros(len(count_dict)), count_dict.values(), step="pre")
            axis.set_yscale("log")
            figure.savefig(plot_name)

        return count_dict

    def calc_means(self, indices, plot=False, plot_name=None):
        """
        This function calculates the mean feature vector set of samples.
        If requested, plots this mean image
        Returns the mean feature vector

        Arguments:
        indices -- the indices of the target samples
        plot -- bool to request a plot
        plot_name -- path to the plot (if requested)
        """
        indices = self._convert_indices(indices)

        X_target = self.X[indices]
        X_mean = X_target.mean(axis=0)

        if plot:
            assert plot_name
            self.plot_features(X_mean, plot_name, title="Mean Image")

        return X_mean

    def get_class(self, label):
        """
        Returns the indices of samples belonging to a given class

        Arguments:
        label -- label of the target class
        """
        assert label in self.y

        # return [0] because y is onedimensional
        return (self.y == label).nonzero()[0]

    def generate_strat_splits(self, size):
        """
        This function calculates randomized, stratified splits (based on the class label) from all samples.
        It ensures that all samples occur at most once and each split has a balanced number of samples per class.

        Yields the indices of samples belonging to the current split.
        The generator returns once at least one class has no more samples remaining

        Arguments:
        size -- size of the split (fraction of data)
        """
        # we wont be able to split everything perfectly. the reason being that the samples are unequally sized
        # we return splits until we can't fill classes anymore...
        # but we shuffle the lists to keep it random

        samples_per_split = int(np.ceil((len(self.y) * size)))
        samples_per_class = int(np.ceil((samples_per_split / len(np.unique(self.y)))))

        mapping = {l: np.random.permutation((self.y == l).nonzero()[0]) for l in np.unique(self.y)}
        i_split = 0
        while True:
            i_start = i_split * samples_per_class

            current_samples_per_class = min([samples_per_class] + [len(x[i_start:]) for x in mapping.values()])
            i_stop = (i_split) * samples_per_class + current_samples_per_class
            target_indices = np.concatenate([x[i_start: i_stop] for x in mapping.values()])
            yield target_indices
            i_split += 1

            # return if we ran out of samples for a class
            if current_samples_per_class < samples_per_class:
                return

    # this is a mere helper function. we can expose it as it doesnt do anything mean
    def plot_features(self, features, output_path, num_rows=None, num_cols=None, title=""):
        """
        Plots a feature vector. It is pretty similar to the plot sample funcion from the reader.
        Allows for better customisation which can be handy in later tasks
        """

        if not num_rows:
            num_rows = self._reader.num_rows
        if not num_cols:
            num_cols = self._reader.num_cols

        sample_features = features.reshape((num_rows, num_cols))
        figure, axis = plt.subplots(figsize=(7, 7))
        axis.imshow(sample_features, interpolation='nearest', cmap='Greys')
        axis.set_title(title)
        axis.set_xticks([])
        axis.set_yticks([])

        figure.savefig(output_path)

    # we have a lot of functions that use indices. Let's outsource the typecheck
    def _convert_indices(self, indices):
        """
        Performs type checks and returns the indices as a numpy array. 
        Converts the string "all" to index all samples
        """
        if isinstance(indices, str):
            if indices == "all":
                indices = np.arange(len(self.y))
        assert isinstance(indices, (np.ndarray, list))

        return np.array(indices)
