import os
import pickle


from .reader import Reader

class PickleReader(Reader):
    def __init__(self, data_dir):
        """Constructor. 
        Arguments:
        data_dir -- the directory containing the data pickle.
        """
        super().__init__(data_dir)
        
    def read_data(self, pickle_name):
        """[private] Overrides the read_data function from the parent class.
        Restores the data from previously dumped pickle files.
        
        Arguments: 
        features -- Tuple (file_name, magic number) for the feature file.
        labels -- Tuple (file_name, magic number) for the labels file.
        """
        
        pickle_path = os.path.join(self._data_dir, pickle_name)
        
        if not os.path.isfile(pickle_path):
            raise FileNotFoundError("Could not find the data pickle file")
        
        try:
            with open(pickle_path, "rb") as pickle_file:
                pickle_data = pickle.load(pickle_file)
        except OSError:
            print("Pickle file could not be loaded")

        self._X = pickle_data["X"]
        self._y = pickle_data["y"]
        self._num_rows = pickle_data["num_rows"]
        self._num_cols = pickle_data["num_cols"]